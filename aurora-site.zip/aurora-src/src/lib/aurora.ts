export type RiskLevel = "LOW" | "MODERATE" | "HIGH";

export function classifyRisk(message: string): RiskLevel {
  const t = message.toLowerCase();
  const high = ["suicídio", "suicidio", "me matar", "morrer", "não quero viver", "nao quero viver", "me machucar", "acabar com tudo"];
  const moderate = ["sem esperança", "sem esperanca", "desespero", "não aguento", "nao aguento", "sozinho", "sozinha", "ninguém liga"];
  if (high.some((x) => t.includes(x))) return "HIGH";
  if (moderate.some((x) => t.includes(x))) return "MODERATE";
  return "LOW";
}

export function reply(message: string): { risk: RiskLevel; content: string } {
  const risk = classifyRisk(message);
  const t = message.toLowerCase();
  if (risk === "HIGH")
    return { risk, content: "Sinto muito que você esteja passando por isso. Você não está sozinho(a). Agora, procure uma pessoa de confiança e ligue para o CVV (188), gratuito e 24h. Em uma emergência, ligue para o SAMU (192)." };
  if (risk === "MODERATE")
    return { risk, content: "Parece que você está carregando algo muito pesado. Se puder, converse com alguém de confiança e considere buscar apoio profissional. Quer tentar uma respiração curta comigo agora?" };
  if (/(prova|estud|vestibular|enem|nota|trabalho)/.test(t))
    return { risk, content: "A pressão dos estudos pode pesar mesmo. Que tal dividir a tarefa em partes pequenas e fazer uma pausa de 5 minutos a cada bloco? O que está mais difícil agora?" };
  if (/(ansios|nervos|medo|preocupad)/.test(t))
    return { risk, content: "Ansiedade é desconfortável, mas passa. Tente inspirar por 4 segundos, segurar 4 e soltar por 4. Quer me contar o que despertou isso?" };
  if (/(dormir|sono|cansad)/.test(t))
    return { risk, content: "Descansar também é cuidar de você. Tente afastar telas 30 minutos antes de dormir. Na aba Autocuidado tem um relaxamento para a noite." };
  return { risk, content: "Obrigado por compartilhar. Quer me contar um pouco mais sobre o que aconteceu hoje? Podemos organizar seus pensamentos juntos." };
}

export const moods = [
  { value: 1, emoji: "😢", label: "Muito mal" },
  { value: 2, emoji: "😕", label: "Mal" },
  { value: 3, emoji: "😐", label: "Neutro" },
  { value: 4, emoji: "🙂", label: "Bem" },
  { value: 5, emoji: "😄", label: "Muito bem" },
];

export type CheckIn = { date: string; mood: number; feelings: string[]; note: string };
const KEY = "aurora-checkins";
export const loadCheckins = (): CheckIn[] => {
  try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch { return []; }
};
export const saveCheckin = (c: CheckIn) => localStorage.setItem(KEY, JSON.stringify([...loadCheckins(), c]));
