import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/autocuidado")({
  head: () => ({
    meta: [
      { title: "Autocuidado — Aurora" },
      { name: "description", content: "Exercícios rápidos de respiração, grounding e pausas para estudantes." },
      { property: "og:title", content: "Autocuidado — Aurora" },
      { property: "og:description", content: "Práticas simples para desacelerar e cuidar de você." },
    ],
  }),
  component: Autocuidado,
});

const exercises = [
  { t: "Respiração 4–4–4", c: "Ansiedade", d: "2 min", steps: ["Inspire pelo nariz contando até 4.", "Segure o ar contando até 4.", "Solte devagar pela boca contando até 4.", "Repita 5 vezes, no seu ritmo."], breathe: true },
  { t: "Grounding 5-4-3-2-1", c: "Ansiedade", d: "5 min", steps: ["Note 5 coisas que você vê.", "4 coisas que pode tocar.", "3 sons que escuta.", "2 cheiros ao redor.", "1 sabor ou algo bom sobre você."] },
  { t: "Pausa consciente", c: "Estudos", d: "3 min", steps: ["Afaste-se da tela.", "Alongue ombros e pescoço.", "Beba um copo de água.", "Volte com uma única tarefa pequena."] },
  { t: "Relaxamento para dormir", c: "Sono", d: "5 min", steps: ["Deite-se confortavelmente.", "Relaxe os pés, depois as pernas.", "Suba relaxando barriga, peito e ombros.", "Solte o rosto e respire devagar."] },
  { t: "Diário de gratidão", c: "Autoestima", d: "5 min", steps: ["Escreva 3 coisas boas de hoje.", "Por que cada uma foi importante?", "Reconheça algo que você fez bem."] },
  { t: "Foco de 5 minutos", c: "Estudos", d: "5 min", steps: ["Escolha a menor parte da tarefa.", "Coloque um timer de 5 minutos.", "Trabalhe só nela.", "Comemore — começar é o mais difícil."] },
];

function Breath() {
  const phases = ["Inspire", "Segure", "Solte", "Segure"];
  const [i, setI] = useState(0);
  useEffect(() => { const id = setInterval(() => setI((x) => (x + 1) % 4), 4000); return () => clearInterval(id); }, []);
  return (
    <div className="my-6 flex flex-col items-center">
      <div className="flex h-44 w-44 items-center justify-center">
        <div className="bg-sun h-44 w-44 rounded-full transition-transform duration-[4000ms] ease-in-out" style={{ transform: `scale(${i === 0 || i === 1 ? 1 : 0.55})` }} />
      </div>
      <p className="mt-2 font-display text-2xl">{phases[i]}</p>
    </div>
  );
}

function Autocuidado() {
  const [open, setOpen] = useState<number | null>(null);
  const ex = open !== null ? exercises[open] : null;
  return (
    <main className="mx-auto max-w-5xl px-5 py-12">
      <h1 className="text-4xl font-semibold">Autocuidado</h1>
      <p className="mt-2 text-muted-foreground">Práticas curtas para desacelerar. Escolha uma e comece.</p>
      <div className="mt-4 h-1 w-16 rounded-full bg-primary/70" />
      {ex && (
        <div className="card-soft mt-8 p-6 md:p-8">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-sm font-semibold text-gold-deep">{ex.c} · {ex.d}</span>
              <h2 className="text-3xl font-semibold">{ex.t}</h2>
            </div>
            <button onClick={() => setOpen(null)} className="rounded-full bg-secondary px-4 py-2 text-sm">Fechar</button>
          </div>
          {ex.breathe && <Breath />}
          <ol className="mt-4 grid gap-2">
            {ex.steps.map((s, i) => (
              <li key={s} className="flex gap-3 rounded-xl bg-secondary p-3"><span className="font-bold text-gold-deep">{i + 1}</span>{s}</li>
            ))}
          </ol>
        </div>
      )}
      <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {exercises.map((e, i) => (
          <button key={e.t} onClick={() => { setOpen(i); window.scrollTo({ top: 0, behavior: "smooth" }); }} className="card-soft p-6 text-left transition hover:-translate-y-1">
            <span className="text-sm font-semibold text-gold-deep">{e.c} · {e.d}</span>
            <h2 className="mt-2 text-xl font-semibold">{e.t}</h2>
            <p className="mt-2 text-sm font-semibold text-gold-deep">Começar →</p>
          </button>
        ))}
      </div>
    </main>
  );
}
