import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { reply, type RiskLevel } from "@/lib/aurora";

export const Route = createFileRoute("/acolhimento")({
  head: () => ({
    meta: [
      { title: "Conversar — Aurora" },
      { name: "description", content: "Um chat de acolhimento para organizar o que você está sentindo." },
      { property: "og:title", content: "Conversar — Aurora" },
      { property: "og:description", content: "Chat de acolhimento seguro, com orientação para ajuda quando necessário." },
    ],
  }),
  component: Chat,
});

type Msg = { from: "me" | "aurora"; text: string; risk?: RiskLevel };

function Chat() {
  const [msgs, setMsgs] = useState<Msg[]>([{ from: "aurora", text: "Oi! Eu sou a Aurora 🌅 Como você está se sentindo agora?" }]);
  const [text, setText] = useState("");
  const send = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    const r = reply(text);
    setMsgs((m) => [...m, { from: "me", text }, { from: "aurora", text: r.content, risk: r.risk }]);
    setText("");
  };
  return (
    <main className="mx-auto flex max-w-2xl flex-col px-5 py-10">
      <h1 className="text-4xl font-semibold">Preciso conversar</h1>
      <p className="mt-2 text-sm text-muted-foreground">A Aurora acolhe, mas não substitui um profissional. Nada aqui é diagnóstico.</p>
      <div className="mt-4 h-1 w-16 rounded-full bg-primary/70" />
      <div className="card-soft mt-6 flex min-h-[420px] flex-col gap-3 p-5">
        {msgs.map((m, i) => (
          <div key={i} className={`max-w-[85%] rounded-2xl px-4 py-3 ${m.from === "me" ? "self-end bg-primary text-primary-foreground" : "self-start bg-secondary"}`}>
            {m.text}
            {m.risk === "HIGH" && (
              <div className="mt-3 flex gap-2">
                <a href="tel:188" className="rounded-full bg-gold px-4 py-1 text-sm font-semibold text-night">Ligar CVV 188</a>
                <a href="tel:192" className="rounded-full bg-card px-4 py-1 text-sm font-semibold text-foreground ring-1 ring-gold/60">SAMU 192</a>
              </div>
            )}
            {m.risk === "MODERATE" && <Link to="/autocuidado" className="mt-2 block text-sm font-semibold text-gold-deep underline">Fazer uma respiração</Link>}
          </div>
        ))}
      </div>
      <form onSubmit={send} className="mt-4 flex gap-2">
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Escreva o que está sentindo..." className="flex-1 rounded-full border border-border bg-card px-5 py-3 outline-none focus:border-primary" />
        <button className="rounded-full bg-primary px-6 font-semibold text-primary-foreground">Enviar</button>
      </form>
    </main>
  );
}
