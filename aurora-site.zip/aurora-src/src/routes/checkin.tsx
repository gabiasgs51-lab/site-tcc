import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { moods, loadCheckins, saveCheckin, type CheckIn } from "@/lib/aurora";

export const Route = createFileRoute("/checkin")({
  head: () => ({
    meta: [
      { title: "Check-in emocional — Aurora" },
      { name: "description", content: "Registre como você está se sentindo hoje e veja seu histórico de humor." },
      { property: "og:title", content: "Check-in emocional — Aurora" },
      { property: "og:description", content: "Registre seu humor diário e acompanhe sua evolução." },
    ],
  }),
  component: CheckinPage,
});

const feelings = ["Ansioso(a)", "Cansado(a)", "Tranquilo(a)", "Triste", "Motivado(a)", "Sobrecarregado(a)", "Grato(a)", "Irritado(a)"];

function CheckinPage() {
  const [mood, setMood] = useState<number | null>(null);
  const [sel, setSel] = useState<string[]>([]);
  const [note, setNote] = useState("");
  const [history, setHistory] = useState<CheckIn[]>([]);
  const [done, setDone] = useState(false);
  useEffect(() => setHistory(loadCheckins()), []);

  const submit = () => {
    if (!mood) return;
    saveCheckin({ date: new Date().toISOString(), mood, feelings: sel, note });
    setHistory(loadCheckins());
    setDone(true);
  };
  const recent = history.slice(-7);
  const lowStreak = history.slice(-3).length === 3 && history.slice(-3).every((c) => c.mood <= 2);

  return (
    <main className="mx-auto max-w-3xl px-5 py-12">
      <h1 className="text-4xl font-semibold">Como você está hoje?</h1>
      <div className="mt-4 h-1 w-16 rounded-full bg-primary/70" />
      {done ? (
        <div className="card-soft mt-8 p-8 text-center">
          <div className="text-5xl">🌅</div>
          <h2 className="mt-4 text-2xl font-semibold">Obrigado por se cuidar.</h2>
          <p className="mt-2 text-muted-foreground">
            {mood && mood <= 2 ? "Dias difíceis acontecem. Que tal uma pausa ou conversar com alguém?" : "Seu registro foi salvo."}
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link to="/autocuidado" className="rounded-full bg-primary px-5 py-2 font-semibold text-primary-foreground">Fazer um exercício</Link>
            <button onClick={() => { setDone(false); setMood(null); setSel([]); setNote(""); }} className="rounded-full bg-secondary px-5 py-2 font-semibold">Novo registro</button>
          </div>
        </div>
      ) : (
        <div className="card-soft mt-8 p-6 md:p-8">
          <div className="grid grid-cols-5 gap-2">
            {moods.map((m) => (
              <button key={m.value} onClick={() => setMood(m.value)} aria-pressed={mood === m.value}
                className={`min-w-0 rounded-2xl px-1 py-3 text-center sm:p-3 transition ${mood === m.value ? "bg-primary text-primary-foreground" : "bg-secondary hover:bg-muted"}`}>
                <div className="text-2xl sm:text-3xl md:text-4xl">{m.emoji}</div>
                <div className="mt-1 truncate text-[11px] font-medium sm:text-xs">{m.label}</div>
              </button>
            ))}
          </div>
          <h2 className="mt-8 text-lg font-semibold"><span className="text-gold-deep">✦</span> O que você está sentindo?</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {feelings.map((f) => (
              <button key={f} onClick={() => setSel((s) => (s.includes(f) ? s.filter((x) => x !== f) : [...s, f]))}
                className={`rounded-full border px-4 py-2 text-sm ${sel.includes(f) ? "border-gold bg-gold/25 text-gold-deep" : "border-border"}`}>{f}</button>
            ))}
          </div>
          <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Quer escrever algo? (opcional)"
            className="mt-6 h-24 w-full rounded-2xl border border-border bg-background p-4 outline-none focus:border-primary" />
          <button disabled={!mood} onClick={submit} className="mt-4 w-full rounded-full bg-primary py-3 font-semibold text-primary-foreground disabled:bg-secondary disabled:text-muted-foreground">Salvar check-in</button>
        </div>
      )}

      {lowStreak && (
        <div className="mt-6 rounded-2xl border border-primary/40 bg-primary/10 p-5">
          <strong>Percebemos que os últimos dias foram difíceis.</strong> Conversar com alguém pode ajudar.{" "}
          <Link to="/ajuda" className="font-semibold text-gold-deep underline">Ver canais de ajuda</Link>
        </div>
      )}

      <section className="mt-12">
        <h2 className="text-2xl font-semibold">Seu histórico</h2>
        {recent.length === 0 ? (
          <p className="mt-3 text-muted-foreground">Seus registros aparecerão aqui.</p>
        ) : (
          <div className="card-soft mt-4 flex h-48 items-end gap-3 p-6">
            {recent.map((c, i) => (
              <div key={i} className="flex flex-1 flex-col items-center gap-2">
                <span className="text-xl">{moods[c.mood - 1]?.emoji}</span>
                <div className="w-full rounded-t-xl bg-sheen" style={{ height: `${c.mood * 18}px` }} />
                <span className="text-xs text-muted-foreground">{new Date(c.date).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })}</span>
              </div>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
