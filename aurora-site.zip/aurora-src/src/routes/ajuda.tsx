import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/ajuda")({
  head: () => ({
    meta: [
      { title: "Canais de ajuda — Aurora" },
      { name: "description", content: "CVV 188, SAMU 192, CAPS e outros canais oficiais de apoio emocional." },
      { property: "og:title", content: "Canais de ajuda — Aurora" },
      { property: "og:description", content: "Você não precisa enfrentar isso sozinho. Encontre ajuda agora." },
    ],
  }),
  component: Ajuda,
});

function Ajuda() {
  return (
    <main className="mx-auto max-w-3xl px-5 py-12">
      <h1 className="text-4xl font-semibold md:text-5xl">Você não precisa enfrentar isso sozinho.</h1>
      <div className="mt-5 h-1 w-16 rounded-full bg-primary/70" />
      <div className="mt-8 grid gap-4 md:grid-cols-2">
        {[
          { n: "CVV — 188", d: "Apoio emocional e prevenção do suicídio. Gratuito, 24 horas.", tel: "188" },
          { n: "SAMU — 192", d: "Para situações de urgência ou emergência.", tel: "192" },
        ].map((c) => (
          <div key={c.tel} className="card-soft p-6">
            <h2 className="text-2xl font-semibold">{c.n}</h2>
            <p className="mt-2 text-muted-foreground">{c.d}</p>
            <a href={`tel:${c.tel}`} className="mt-4 inline-block rounded-full bg-gold px-5 py-2 font-semibold text-night">Ligar {c.tel}</a>
          </div>
        ))}
      </div>
      <div className="mt-4 grid gap-4">
        <div className="rounded-2xl border-l-4 border-gold bg-secondary p-6">
          <h2 className="text-xl font-semibold">Pessoa de confiança</h2>
          <p className="mt-2 text-muted-foreground">Procure alguém que possa ficar com você: família, amigos, professores ou a coordenação da escola.</p>
        </div>
        <div className="rounded-2xl border-l-4 border-gold bg-secondary p-6">
          <h2 className="text-xl font-semibold">Serviços de saúde</h2>
          <p className="mt-2 text-muted-foreground">CAPS · UBS · Serviço de psicologia da escola ou faculdade · Assistência estudantil</p>
        </div>
        <a href="https://cvv.org.br/chat/" target="_blank" rel="noreferrer" className="card-soft p-6 transition hover:-translate-y-1">
          <h2 className="text-xl font-semibold">Prefere escrever? Chat do CVV →</h2>
        </a>
      </div>
    </main>
  );
}
