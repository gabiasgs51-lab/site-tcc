import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Aurora — Apoio à saúde mental de estudantes" },
      { name: "description", content: "Check-in emocional, autocuidado, acolhimento e canais de ajuda para estudantes." },
      { property: "og:title", content: "Aurora — Apoio à saúde mental de estudantes" },
      { property: "og:description", content: "Um espaço acolhedor para cuidar da mente durante a vida escolar." },
    ],
  }),
  component: Index,
});

const features = [
  { to: "/checkin", icon: "🌤️", title: "Como estou hoje?", text: "Registre seu humor em segundos e acompanhe sua semana." },
  { to: "/autocuidado", icon: "🌿", title: "Quero relaxar", text: "Respiração, grounding e pausas para os estudos." },
  { to: "/acolhimento", icon: "💬", title: "Preciso conversar", text: "Um chat acolhedor para organizar o que você sente." },
  { to: "/ajuda", icon: "🤝", title: "Preciso de ajuda", text: "CVV, SAMU, CAPS e outros canais oficiais." },
] as const;

function Index() {
  return (
    <main>
      <section className="relative overflow-hidden bg-dawn">
        <div className="bg-sun animate-rise absolute -bottom-52 left-1/2 h-[560px] w-[560px] -translate-x-1/2 rounded-full opacity-55" />
        <div className="relative mx-auto max-w-4xl px-5 pb-32 pt-20 text-center">
          <span className="rounded-full bg-secondary/80 px-4 py-2 text-sm font-semibold text-gold-deep ring-1 ring-gold/30">Um espaço para você</span>
          <h1 className="mt-6 text-5xl font-semibold leading-tight text-foreground md:text-7xl">
            Cuidar da mente também faz parte da vida escolar.
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-lg text-foreground">
            Acompanhe como você está, pratique autocuidado e encontre ajuda quando precisar. Toda noite termina em aurora.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/checkin" className="rounded-full bg-gold px-6 py-3 font-semibold text-night shadow-soft hover:opacity-90">Fazer check-in</Link>
            <Link to="/ajuda" className="rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground hover:opacity-90">Preciso de ajuda</Link>
          </div>
        </div>
      </section>

      <section id="apoio" className="mx-auto -mt-16 grid max-w-6xl gap-4 px-5 sm:grid-cols-2 lg:grid-cols-4">
        {features.map((f) => (
          <Link key={f.to} to={f.to} className="card-soft relative p-6 transition hover:-translate-y-1">
            <div className="text-4xl">{f.icon}</div>
            <div className="mt-4 h-1 w-10 rounded-full bg-gold/80" />
            <h2 className="mt-3 text-xl font-semibold">{f.title}</h2>
            <p className="mt-2 text-sm text-muted-foreground">{f.text}</p>
          </Link>
        ))}
      </section>

      <section className="mx-auto mt-24 grid max-w-6xl gap-10 px-5 md:grid-cols-2 md:items-center">
        <div>
          <h2 className="text-4xl font-semibold">Por que o Aurora existe</h2>
          <p className="mt-4 text-muted-foreground">
            Ansiedade, pressão por resultados e cansaço fazem parte da rotina de muitos estudantes. O Aurora nasceu
            para ajudar na prevenção e na conscientização, com linguagem simples e muito cuidado.
          </p>
        </div>
        <ul className="grid gap-3">
          {["Acolhimento sem julgamentos", "Seus registros ficam só no seu aparelho", "Não faz diagnósticos e não substitui profissionais", "Orienta para ajuda em situações de risco"].map((x) => (
            <li key={x} className="flex items-center gap-3 rounded-2xl bg-secondary px-5 py-4 font-medium">
              <span className="text-gold-deep">✦</span> {x}
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
