import { Link } from "@tanstack/react-router";

const links = [
  { to: "/checkin", label: "Check-in" },
  { to: "/autocuidado", label: "Autocuidado" },
  { to: "/acolhimento", label: "Conversar" },
] as const;

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-20 border-b border-border/60 bg-background/80 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-5 sm:py-4">
        <Link to="/" className="font-display text-2xl font-semibold text-foreground">
          Aurora<span className="text-gold">.</span>
        </Link>
        <nav className="flex items-center gap-1 text-sm font-medium">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="hidden rounded-full px-3 py-2 text-muted-foreground hover:text-foreground sm:inline"
              activeProps={{ className: "text-foreground bg-secondary" }}
            >
              {l.label}
            </Link>
          ))}
          <Link to="/ajuda" className="shrink-0 rounded-full bg-gold px-4 py-2.5 font-semibold sm:py-2 text-night hover:opacity-90">
            Preciso de ajuda
          </Link>
        </nav>
      </div>
      <nav className="grid grid-cols-3 gap-1 border-t border-border/60 px-2 py-1.5 text-sm sm:hidden">
        {links.map((l) => (
          <Link key={l.to} to={l.to} className="flex min-h-11 items-center justify-center rounded-full px-2 text-muted-foreground" activeProps={{ className: "bg-secondary text-gold-deep font-semibold ring-1 ring-gold/60" }}>
            {l.label}
          </Link>
        ))}
      </nav>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-20 border-t border-gold/50 bg-secondary/50">
      <div className="mx-auto max-w-6xl px-5 py-8 text-sm text-muted-foreground">
        <p>
          O Aurora oferece apoio e informações educativas. Ele <strong>não substitui</strong> avaliação ou
          tratamento com profissionais de saúde. Em risco imediato, ligue <strong>CVV 188</strong> ou{" "}
          <strong>SAMU 192</strong>.
        </p>
        <p className="mt-3">Aurora · Projeto de TCC — Técnico em Informática · E.E. Padre Emídio Viana Correia, Campina Grande – PB</p>
      </div>
    </footer>
  );
}
